using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class Character : MonoBehaviour
{
    public float moveSpeed = 5.0f;
    public float jumpForce = 5.0f;
    public Rigidbody rb;
    public bool isGround = true;

    private float cameraX;

    public StatsManager playerStats;

    public Camera camera;

    private bool canDash = true;
    public float dashCooldown = 0.5f;
    public float staminaCost;
    public float dashCost;
    void Awake()
    {
        playerStats = GetComponent<StatsManager>();
    }


    void Update()
    {
        ForwardCamera();
        MovePlayer();
        ChangeFov();



    }

    void ForwardCamera()
    {
        cameraX = GetComponent<CameraOrbit>().cameraX;
    }

    void MovePlayer()
    {
        UnityEngine.Vector3 move = transform.forward * Input.GetAxis("Vertical") + transform.right * Input.GetAxis("Horizontal");

        UnityEngine.Vector3 velocity = move * moveSpeed;
        velocity.y = rb.linearVelocity.y;
        rb.linearVelocity = velocity;

        transform.rotation = Quaternion.Euler(0, cameraX, 0);

        if (Input.GetKeyDown(KeyCode.Space) && canDash && playerStats.currentStamina >= dashCost)
        {
            StartCoroutine(DashForward());
            playerStats.currentStamina -= dashCost;
        }
    }



    IEnumerator DashForward()
    {
        float dashForce = 20f;
        float dashDuration = 0.2f;

        canDash = false;
        Vector3 dashDirection = transform.forward;
        float startTime = Time.time;

        while (Time.time < startTime + dashDuration)
        {
            rb.linearVelocity = dashDirection * dashForce;
            yield return null;
        }

        yield return new WaitForSeconds(dashCooldown);
        canDash = true;
    }



    void ChangeFov()
    {
        if (Input.GetKey(KeyCode.LeftShift) && playerStats.currentStamina >= staminaCost)
        {
            camera.GetComponent<Camera>().fieldOfView = Mathf.Lerp(camera.fieldOfView, 85, Time.deltaTime * 5);
            moveSpeed = 8;

            playerStats.currentStamina -= staminaCost * Time.deltaTime;
        }
        else
        {
            camera.fieldOfView = Mathf.Lerp(camera.fieldOfView, 75, Time.deltaTime * 5);
            moveSpeed = 5;
        }

    }

}



