using UnityEngine;

public class CameraOrbit : MonoBehaviour
{
    public Transform TransformCamera;
    public Transform CameraAlvo;

    public float DistanciaCamera = 5.0f;

    public float VelocidadeRotacao = 500.0f;

    public float cameraX = 0.0f;

    private float cameraY = 0.0f;

    public float MinY = -10f;

    public float MaxY = 60f;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void Update()
    {
        OrbitCamera();
    }

    void OrbitCamera()
    {
        cameraX += Input.GetAxis("Mouse X") * VelocidadeRotacao * Time.deltaTime;
        cameraY -= Input.GetAxis("Mouse Y") * VelocidadeRotacao * Time.deltaTime;


        cameraY = Mathf.Clamp(cameraY, MinY, MaxY);

        Vector3 cameraOffset = new Vector3(0, 0, -DistanciaCamera);
        Quaternion rotation = Quaternion.Euler(cameraY, cameraX, 0);
        TransformCamera.position = CameraAlvo.transform.position + rotation * cameraOffset;

        TransformCamera.LookAt(CameraAlvo.transform.position);
    }
}