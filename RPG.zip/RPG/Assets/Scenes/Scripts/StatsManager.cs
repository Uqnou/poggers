using UnityEngine;

public class StatsManager : MonoBehaviour
{
    public int maxHP = 100;
    public int currentHP;
    public float maxStamina = 100;
    public float currentStamina;
    
    public float staminaRegen = 5f;
    void Awake()
    {
        currentHP = maxHP;
        currentStamina = maxStamina;
    }


    void Update()
    {
        StaminaRegen();

        if (currentHP <= 0)
        {
            Death();
        }
    }

    void StaminaRegen()
    {
        if (currentStamina < maxStamina)
        {
            currentStamina += staminaRegen * Time.deltaTime;
        }
    }

    void Death()
    {
        Destroy(gameObject);
    }
}
