using UnityEngine;

public class Weapons : MonoBehaviour
{
    private bool canPickUp = false;
    private GameObject player;
    private Transform hands;
    private Transform originalParent;
    public bool hasWeapon = false;
    void Start()
    {
        originalParent = transform.parent;
    }

    void Update()
    {
        if (canPickUp && Input.GetKeyDown(KeyCode.E))
        {
            if (hasWeapon == false)
            {
                PickUp();
            }
        }

        if (hasWeapon == true && Input.GetKeyDown(KeyCode.G))
        {
            if (transform.parent == hands)
            {
                Drop();
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {

        if (other.CompareTag("Player"))
        {
            player = other.gameObject;



            hands = FindChildRecursive(player.transform, "Hands");
            if (hands == null)
            {
                Debug.LogWarning("Objeto 'Hands' n�o encontrado dentro do Player!");
            }

            canPickUp = true;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            canPickUp = false;
            player = null;
            hands = null;
        }
    }

    void PickUp()
    {
        if (hands != null)
        {
            transform.SetParent(hands);
            transform.localPosition = Vector3.zero;
            transform.localRotation = Quaternion.identity;
            hasWeapon = true;
        }
    }

    void Drop()
    {
        transform.SetParent(null);
        hasWeapon = false;

    }


    Transform FindChildRecursive(Transform parent, string childName)
    {
        foreach (Transform child in parent)
        {
            if (child.name == childName)
                return child;
            Transform found = FindChildRecursive(child, childName);
            if (found != null)
                return found;
        }
        return null;
    }
}
