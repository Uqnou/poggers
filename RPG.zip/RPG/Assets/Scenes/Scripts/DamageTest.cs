using UnityEngine;
using System.Collections;

public class DamageTest : MonoBehaviour
{
    public int damage;
    public float activeTime = 0.3f;
    public Collider thisCollider;
    private bool isAttacking = false;

    void Start()
    {
        
        thisCollider.enabled = false; 
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0) && !isAttacking)
        {
            StartCoroutine(AtivarCollider());
        }
    }

    IEnumerator AtivarCollider()
    {
        isAttacking = true;
        thisCollider.enabled = true;
        yield return new WaitForSeconds(activeTime);
        thisCollider.enabled = false;
        isAttacking = false;
    }

    void OnTriggerEnter(Collider other)
    {
        StatsManager targetStats = other.GetComponent<StatsManager>();
        if (targetStats != null)
        {
            targetStats.currentHP -= damage;
            Debug.Log("dei " + damage);
        }
    }
}
