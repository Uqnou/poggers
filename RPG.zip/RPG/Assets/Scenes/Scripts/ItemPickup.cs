using UnityEngine;

public class ItemPickup : MonoBehaviour
{
    
    public bool InRange = false;

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {

            InRange = true;


        }
    }

    void Update()
    {
        if (InRange && Input.GetKeyDown(KeyCode.E))
        {
            Destroy(gameObject);
        } 
    }

    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            InRange = false;

        }
    }
}
